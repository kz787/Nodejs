const fs = require('fs')
fs.writeFileSync("file.txt","Hello Class!");