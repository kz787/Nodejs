// const fs = require('fs')
// fs.writeFileSync("file.txt","Hello Class!");

// const readline = require("readline");

// const rl = readline.createInterface({
//     input: process.stdin,
//     output: process.stdout
// });

// rl.question("What is name? ",function (answer){
//     console.log(`Oh, so your name is ${answer}`);
//     rl.close();
// });

const prompt = require("prompt-sync")();
const input = prompt("What is your name? ");
console.log(`Oh, so your name is ${input}`);